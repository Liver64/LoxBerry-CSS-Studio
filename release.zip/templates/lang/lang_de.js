window.LBDesignStudioLangs = window.LBDesignStudioLangs || {};
window.LBDesignStudioLangs.de = {
  "main": {
    "buttons": {
      "save": "Speichern",
      "saveGenerateCss": "Speichern & CSS erzeugen",
      "delete": "Löschen",
      "cancel": "Abbrechen",
      "validate": "Validieren",
      "test": "Test",
      "close": "Schließen",
      "apply": "Übernehmen",
      "undo": "↶ Rückgängig",
      "ok": "OK",
      "back": "Zurück"
    },
    "common": {
      "yes": "Ja",
      "no": "Nein",
      "auto": "Auto",
      "none": "Keine",
      "enabled": "Aktiviert",
      "disabled": "Deaktiviert"
    },
    "status": {
      "title": "Status"
    }
  },
  "studio": {
    "title": "LoxBerry Design Studio",
    "subtitle": "Theme-Gestaltung über verständliche Elemente. Core-Tokens werden intern automatisch zugeordnet. Elemente können direkt in der Preview angeklickt werden."
  },
  "toolbar": {
    "userTheme": "User Theme",
    "currentPreviewNewTheme": "Aktuelle Preview / neues Theme"
  },
  "tabs": {
    "ariaLabel": "Design Studio Bereiche",
    "designStudio": "Design Studio",
    "aiDesigner": "KI Designer",
    "preview": "Live Vorschau",
    "documentation": "Dokumentation"
  },
  "inspector": {
    "selectedElement": "Ausgewähltes Element",
    "selectedCardTitle": "Aktuell ausgewähltes Element; Eigenschaftskacheln wählen gezielt die jeweilige Eigenschaft",
    "selectedEyebrow": "Preview Auswahl",
    "emptyMeta": "0 Eigenschaften · 0 Tokens",
    "noMapping": "Keine Tokens im Mapping",
    "moreTokens": "weitere",
    "fewerTokens": "weniger",
    "noToken": "kein Token",
    "propertyTitlePrefix": "Klick: Eigenschaft wählen · + weitere klappt zusätzliche Tokens auf"
  },
  "properties": {
    "ariaLabel": "Eigenschaften des gewählten Elements",
    "area": "Bereich",
    "elementVariant": "Element / Variante",
    "property": "Eigenschaft",
    "tableCellLines": "Zelllinien",
    "tableCellLineWidth": "Zelllinien Stärke"
  },
  "tokens": {
    "showAffected": "Alle betroffenen Tokens anzeigen",
    "token": "Token",
    "tokens": "Tokens",
    "internalTokens": "interne Tokens"
  },
  "components": {
    "inputText": "Input Text"
  },
  "palette": {
    "title": "4. Vorschaufarben",
    "ariaLabel": "Farbpalette",
    "customColorAria": "Eigene Farbe wählen",
    "roles": {
      "text": "Text",
      "border": "Rahmen",
      "hover": "Hover",
      "active": "Aktiv",
      "primary": "Primär",
      "button": "Button",
      "input": "Eingabe",
      "surface": "Fläche",
      "background": "Hintergrund",
      "table": "Tabelle",
      "sidebar": "Sidebar",
      "slider": "Slider",
      "form": "Formular"
    }
  },
  "componentInspector": {
    "mapping": "Mapping:",
    "hint": "Normaler Klick wählt das Element im Design Studio aus.",
    "hoverHint": "Klick: auswählen"
  },
  "directEditor": {
    "title": "Auswahlhilfe",
    "closeAria": "Auswahlhilfe schließen",
    "hint": "Normaler Klick wählt das Element im Design Studio aus.",
    "noElement": "Kein Element gewählt",
    "focusSettings": "Einstellungen fokussieren",
    "improveWithAi": "Dieses Element mit KI verbessern"
  },
  "settings": {
    "title": "Einstellungen",
    "color": "Farbe",
    "opacity": "Deckkraft",
    "brightness": "Helligkeit",
    "radius": "Radius",
    "borderWidth": "Rahmenstärke",
    "shadowDepth": "Schatten / Tiefe"
  },
  "import": {
    "title": "5. CSS Import",
    "hint": "Importierte CSS wird als Custom CSS übernommen. Bekannte --lb-* Tokens werden zusätzlich in die finale Preview übernommen und beim Speichern als JSON-Quelle gesichert. Nicht tokenisierbare Spezialregeln, z. B. Blur, Backdrop-Filter oder Wallpaper-Regeln, bleiben im Custom-CSS-Block erhalten.",
    "showCustomCss": "Custom CSS anzeigen",
    "summaryTitle": "Hybrid-Import",
    "summaryTokens": "{count} Core-Tokens erkannt",
    "summaryCustom": "{count} individuelle CSS-Regeln erhalten",
    "summaryEffects": "Erkannte Effekte: {effects}",
    "summaryNoEffects": "Keine speziellen Effekte erkannt",
    "effects": {
      "backdropFilter": "Backdrop-Filter",
      "blur": "Blur",
      "transparency": "Transparenz",
      "wallpaper": "Wallpaper",
      "shadows": "Schatten"
    }
  },
  "preview": {
    "title": "Arbeitsbereich / Vorschau",
    "workHint": "Klicke einzelne Elemente an, um sie im Studio zu bearbeiten.",
    "caption": "Kein Element ausgewählt.",
    "internalTokens": "interne Tokens",
    "nav": {
      "dashboard": "Dashboard",
      "settings": "Settings",
      "logfiles": "Logfiles"
    },
    "edit": {
      "headerButtons": "Header Buttons bearbeiten",
      "inputText": "Input Text bearbeiten",
      "select": "Select bearbeiten",
      "button": "Button bearbeiten",
      "activeButton": "Active Button bearbeiten",
      "buttonGroup": "Button Gruppe bearbeiten",
      "input": "Input bearbeiten",
      "dropdown": "Dropdown bearbeiten",
      "textarea": "Textarea bearbeiten",
      "slider": "Slider bearbeiten",
      "checkbox": "Checkbox bearbeiten",
      "radio": "Radio bearbeiten",
      "toggle": "Toggle bearbeiten",
      "validation": "Validation bearbeiten",
      "modal": "Modal bearbeiten",
      "table": "Tabelle bearbeiten",
      "background": "Hintergrund bearbeiten",
      "sidebar": "Sidebar-Hintergrund bearbeiten"
    },
    "card": {
      "title": "Plugin Card / Note",
      "text": "Kurze neutrale Vorschau einer typischen LoxBerry-Seite."
    },
    "form": {
      "select": "Select",
      "option": "Option",
      "button": "Button",
      "active": "Active",
      "inputText": "Input Text"
    },
    "forms": {
      "title": "Formulare",
      "input": "Input",
      "dropdown": "Dropdown",
      "textarea": "Textarea",
      "slider": "Slider",
      "checkbox": "Checkbox",
      "radio": "Radio",
      "toggle": "Toggle",
      "textValue": "Text"
    },
    "feedback": {
      "success": "Alles in Ordnung!",
      "warning": "Validation Hinweis",
      "openModal": "Modal öffnen"
    },
    "table": {
      "name": "Name",
      "type": "Typ",
      "status": "Status",
      "action": "Aktion",
      "livingRoom": "Wohnzimmer",
      "standard": "Standard",
      "online": "Online",
      "selection": "Auswahl",
      "kitchen": "Küche",
      "compact": "Compact",
      "standby": "Standby",
      "bath": "Bad",
      "hover": "Hover",
      "offline": "Offline",
      "value": "Wert"
    },
    "toggleOffTitle": "Aus / Hintergrund",
    "toggleOnTitle": "Ein / Aktiv",
    "editAria": "Klicken zum Bearbeiten",
    "sampleColor": "Beispielfarbe"
  },
  "previewPage": {
    "previewSliderLevelLabel": "Level:",
    "previewSliderLevelValue": "50 %",
    "previewSliderPercentMin": "0 %",
    "previewSliderPercentMax": "100 %",
    "previewSliderCacheLabel": "Cache:",
    "previewSliderCacheValue": "500 MB",
    "previewSliderCacheMin": "100 MB",
    "previewSliderCacheMax": "3000 MB",
    "previewSliderDisabledLabel": "Disabled:",
    "previewSliderDisabledValue": "40 %",
    "previewSliderPercentSuffix": " %",
    "previewSliderMegabyteSuffix": " MB"
  },
  "wallpaper": {
    "title": "Wallpaper Editor",
    "enabled": "Wallpaper aktivieren",
    "image": "Wallpaper-Pfad / Data-URL",
    "file": "Wallpaper-Datei",
    "chooseFile": "Datei wählen",
    "noFile": "Keine Datei ausgewählt",
    "imagePlaceholder": "theme-file.cgi?file=assets%2Fimages%2Ftheme%2Fwallpaper.jpg",
    "mode": "Darstellung",
    "modeCover": "Cover",
    "modeContain": "Contain",
    "modeRepeat": "Wiederholen",
    "modeCenter": "Zentriert",
    "brightness": "Wallpaper-Helligkeit",
    "opacity": "Wallpaper-Transparenz"
  },
  "ai": {
    "title": "KI Designer",
    "hint": "Die KI ist auf CSS- und Theme-Aufgaben eingeschränkt und wird durch einen Guard in ihrer Funktion restriktiert. Bitte keine personenbezogenen Daten, Passwörter, API-Keys, Konfigurationsdateien oder vertrauliche Inhalte eingeben. Die KI erzeugt nur einen semantischen Theme-Entwurf zur Weiterbearbeitung im Design Studio. Inputs, Selects, Dropdowns, Tabellen, Buttons, Button-Groups, Header-Buttons und Karten werden danach lokal auf LoxBerry DS-System gemappt. Einzelne Preview-Elemente können per CTRL-/Strg-Klick als KI-Fokus zur Optimierung vorbereitet werden. ",
    "consent": "Ich stimme zu, dass ausschließlich Daten im CSS- und Theme-Kontext und mein Prompt extern über Puter.js verarbeitet werden.",
    "advancedView": "erweiterte Sicht",
    "model": "KI Modell",
    "promptLabel": "Theme-Wunsch",
    "colorDirection": "Farbrichtung",
    "colorDirectionHint": "Klick ergänzt den Prompt als lesbaren Farbwunsch, nicht als Hex-Code.",
    "colorDirectionPrompt": "Verwende als Farbrichtung: {color}.",
    "defaultPrompt": "Erstelle ein modernes, ruhiges LoxBerry Theme mit klaren Kontrasten, abgerundeten Karten, dezenten Buttons und guter Lesbarkeit.",
    "showRequest": "Request anzeigen",
    "generate": "KI Entwurf erzeugen",
    "requestContext": "Request / Kontext",
    "result": "KI Ergebnis",
    "resultHint": "Erwartet wird semantisches JSON mit <code>design.colors</code> und <code>design.components</code>. Vor dem Laden prüft der KI-Guard die Antwort auf erlaubte JSON-/CSS-Inhalte.",
    "loadIntoStudio": "Ins Design Studio laden",
    "previewTitle": "KI Farbpalette",
    "noDraft": "Noch kein KI-Entwurf geladen.",
    "validNoValues": "JSON gültig, aber keine anwendbaren Designwerte enthalten.",
    "adoptedValues": "Übernommene Designwerte",
    "poweredBy": "Powered by Puter.js",
    "colorDirectionAria": "KI Farbrichtung"
  },
  "statusModal": {
    "successTitle": "OK",
    "infoTitle": "Hinweis",
    "warningTitle": "Hinweis",
    "errorTitle": "Fehler",
    "autoCloseHint": "Diese Meldung schließt automatisch nach 5 Sekunden.",
    "manualCloseHint": "Bitte bestätigen."
  },
  "deleteModal": {
    "title": "User Theme löschen",
    "help": "User Theme wirklich löschen? JSON und zugehörige CSS-Datei werden gelöscht, wenn sie vom CSS-Studio erzeugt wurden."
  },
  "saveModal": {
    "title": "Theme speichern",
    "help": "Der Dateiname wird automatisch aus dem Anzeigenamen erzeugt. Ein führendes „LoxBerry“ wird entfernt.",
    "displayName": "Anzeigename / Dateiname",
    "version": "Version",
    "base": "Basis",
    "baseLoxBerry": "LoxBerry / System",
    "baseLiquidGlass": "Liquid Glass",
    "baseRounded": "Rounded",
    "baseClassicMac": "Classic Mac",
    "defaultThemeName": "Demo Theme"
  },
  "messages": {
    "noSaveableContent": "Nicht gespeichert: Es sind keine Theme-Tokens oder nutzbaren Custom-CSS-Regeln vorhanden. Bitte erst KI-Entwurf laden, CSS importieren oder einen Wert ändern.",
    "deleteNoThemeSelected": "Kein User Theme zum Löschen ausgewählt.",
    "deleteConfirm": "User Theme wirklich löschen? JSON und zugehörige CSS-Datei werden gelöscht, wenn sie vom CSS-Studio erzeugt wurden.",
    "deletingTheme": "Lösche User Theme ...",
    "themeDeleted": "Gelöscht: {theme}. Entfernt: JSON {json}, CSS {css}, Manifest {manifest}.",
    "savingTheme": "Speichere Theme und erzeuge CSS ...",
    "legacyCssImported": "Legacy-CSS importiert: {file}. {count} bekannte LoxBerry-Tokens wurden in die finale Preview übernommen. Beim Speichern wird daraus eine JSON-Quelle erzeugt.",
    "hybridCssImported": "Hybrid-CSS importiert: {file}. {tokens} LoxBerry-Tokens erkannt, {rules} individuelle CSS-Regeln erhalten.",
    "cssImportedNoTokens": "CSS importiert: {file}. Keine bekannten --lb-* Tokens gefunden; CSS bleibt als Custom CSS erhalten.",
    "cssReadError": "CSS konnte nicht gelesen werden.",
    "userThemeLoaded": "User Theme geladen: {theme}. Nur die finale Preview wurde aktualisiert.",
    "requestBuilt": "Request-Paket lokal erzeugt und durch KI-Guard geprüft. Noch nichts extern übertragen.",
    "jsonNoObject": "Kein JSON-Objekt.",
    "invalidToken": "Ungültiger Token: {token}",
    "forbiddenCss": "CSS enthält verbotene externe/aktive Inhalte.",
    "aiValid": "KI-Entwurf ist formal gültig und kann geladen werden.",
    "aiValidateFirst": "Bitte den KI-Entwurf zuerst erfolgreich validieren.",
    "aiLoaded": "KI-Entwurf in die Preview geladen. Bitte prüfen und final speichern.",
    "aiConsentRequired": "Bitte zuerst der externen Verarbeitung über Puter.js zustimmen.",
    "aiLoading": "Lade Puter.js und frage KI mit eingeschränktem CSS/JSON/Theme-Kontext an ...",
    "aiReceived": "KI-Antwort erhalten und vom KI-Guard vorgeprüft. Bitte validieren und erst danach ins Design Studio laden.",
    "directEditorFocused": "Auswahl fokussiert: {path}",
    "aiFocusPrepared": "KI-Fokus für {path} vorbereitet. Bei Bedarf Prompt anpassen und KI Entwurf erzeugen.",
    "directEditorOpened": "Auswahl geöffnet: {path}",
    "previewSelected": "Preview-Auswahl übernommen: {path}.",
    "fromPreviewSelected": "aus Preview gewählt",
    "LoxBerryRead": "LoxBerry gelesen: {tokens} Tokens, {themes} Themes.",
    "selectElementFirst": "Bitte zuerst ein Element im Arbeitsbereich / Vorschau oder im Eigenschaftenbereich auswählen.",
    "noRadiusForElement": "Dieses Element besitzt keine Radius-Tokens.",
    "noBorderWidthForElement": "Dieses Element besitzt keine Rahmenstärke-Tokens.",
    "protectedPackageTheme": "Nicht gespeichert: {theme} ist ein geschütztes Paket-Theme und kann im Design Studio nicht überschrieben oder gelöscht werden. Verwende für ein eigenes Theme einen anderen Anzeigenamen.",
    "saveFailed": "Speichern fehlgeschlagen.",
    "themeSaved": "Gespeichert: {theme} {version}. CSS: {css}",
    "previousJsonBackup": "Vorherige JSON: {backup}",
    "cssNotReported": "nicht gemeldet",
    "deleteReadonlyTheme": "Dieses CSS-only Paket-Theme kann nicht direkt gelöscht werden.",
    "deleteFailed": "Löschen fehlgeschlagen.",
    "undoDone": "Letzte Änderung rückgängig gemacht.",
    "puterLoadError": "Puter.js konnte nicht geladen werden.",
    "invalidJsonResponse": "Antwort enthält kein gültiges JSON."
  },
  "undo": {
    "availableTitle": "Letzte Änderung rückgängig machen",
    "emptyTitle": "Keine Änderung zum Rückgängigmachen"
  },
  "customCss": {
    "defaultText": "/* USER CUSTOM CSS START */\n/* Eigene Ergänzungen bleiben beim Speichern erhalten. */\n/* USER CUSTOM CSS END */"
  },
  "serverErrors": {
    "generic": "Ein unbekannter Serverfehler ist aufgetreten.",
    "cannotCreateDirectory": "Verzeichnis kann nicht erstellt werden: {path}",
    "invalidJsonPayload": "Ungültige JSON-Nutzlast.",
    "protectedPackageTheme": "Nicht gespeichert: {theme} ist ein geschütztes Paket-Theme und kann im Design Studio nicht überschrieben oder gelöscht werden. Verwende für ein eigenes Theme einen anderen Anzeigenamen.",
    "cannotBackupPreviousJson": "Vorherige JSON kann nicht gesichert werden: {path}",
    "invalidWallpaperImageData": "Ungültige Wallpaper-Bilddaten.",
    "wallpaperTooLarge": "Wallpaper-Bild ist zu groß. Maximum ist 8 MB.",
    "cannotCreateWallpaperAssetDirectory": "Wallpaper-Asset-Verzeichnis kann nicht erstellt werden: {path}",
    "cannotWriteWallpaperAsset": "Wallpaper-Asset kann nicht geschrieben werden: {path}",
    "cannotFinalizeWallpaperAsset": "Wallpaper-Asset kann nicht finalisiert werden: {path}",
    "emptyTheme": "Keine Theme-Tokens oder nutzbaren Custom-CSS-Regeln empfangen. CSS wäre leer.",
    "cannotWriteFile": "Datei kann nicht geschrieben werden: {path}",
    "cannotCloseWriteFile": "Datei kann nicht abgeschlossen/geschrieben werden: {path}",
    "cssNotCreatedOrEmpty": "CSS wurde nicht erstellt oder ist leer: {path}"
  }
};
